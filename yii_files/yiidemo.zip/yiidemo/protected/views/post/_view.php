    <div id="list_cntntbg2">
      <div id="list_title2"><?php echo CHtml::link(CHtml::encode($data->content), array('view', 'id'=>$data->id)); ?></div>
      <div id="list_mid2">Open</div>
      <div id="list_large2"><?php echo CHtml::encode($data->category_id); ?></div>
      <div id="list_small2">12days</div>
      <div id="list_small2">20</div>
      <div id="list_mid2">32</div>
      <div id="list_large2"></div>
    </div>