<?php
$this->breadcrumbs=array(
	'Posts'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List Post', 'url'=>array('index')),
	array('label'=>'Manage Post', 'url'=>array('admin')),
);
?>
<div id="middleDiv">
   <div id="posting_leftNv">
     <div id="posting_leftNv_head">
        <div id="posting_leftNv_Bttn">

            <label>
              <input type="submit" name="button" id="button" value="Create a  Post" />
            </label>

        </div>
        <div id="posting_leftNv_home">Home</div>
     </div>
     <div id="posting_leftNv_linkHead">Posts</div>
     <div id="posting_leftNv_link2">
       <ul>
           <li>New in All Categories</li>
           <li>New in Your Specialty</li>
           <li>Most Popular</li>
           <li>Category List</li>
           <li>Politics &amp; Reform</li>
       </ul>
     </div>

     <div id="posting_leftNv_linkHead">Your Activity</div>
     <div id="posting_leftNv_link2">
       <ul>
           <li>New in All Categories</li>
           <li>New in Your Specialty</li>
           <li>Most Popular</li>
           <li>Category List</li>
           <li>Politics &amp; Reform</li>
       </ul>
     </div>

     <div id="posting_leftNv_linkHead">From Industry</div>
     <div id="posting_leftNv_link2">
       <ul>
           <li>New in All Categories</li>
           <li>New in Your Specialty</li>
           <li>Most Popular</li>
           <li>Category List</li>
           <li>Politics &amp; Reform</li>
       </ul>
     </div>

     <div id="posting_leftNv_linkHead">Physicians</div>
     <div id="posting_leftNv_link2">
       <ul>
           <li>New in All Categories</li>
           <li>New in Your Specialty</li>
           <li>Most Popular</li>
           <li>Category List</li>
           <li>Politics &amp; Reform</li>
       </ul>
     </div>


     <div id="posting_leftNv_linkHead">Using DocMingle</div>
     <div id="posting_leftNv_link2">
       <ul>
           <li>New in All Categories</li>
           <li>New in Your Specialty</li>
           <li>Most Popular</li>
           <li>Category List</li>
           <li>Politics &amp; Reform</li>
       </ul>
     </div>

   </div>
 <div id="middle_left">
   <div id="left_head">
    <div id="Postinghead"><font id="PostingheadSpan">Post to</font> DocMingle</div>
   </div>
      <?php echo $this->renderPartial('_form', array('model'=>$model)); ?>
   <div id="left_bottom"></div>
 </div>
</div>

